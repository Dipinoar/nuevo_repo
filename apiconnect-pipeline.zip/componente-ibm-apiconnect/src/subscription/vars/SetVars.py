from vars.Formatted import Formatfunc
from vars.Functions import Processfunc
import os
import yaml
import json
import re
import glob

def set_vars():

    filevars = Formatfunc()
    process= Processfunc()
    env_vars = os.environ
    #for var in env_vars:
        #print(f"{var}: {env_vars[var]}")
    environment= "development"
    pathGit = os.environ.get('CI_PROJECT_NAMESPACE')
    projectPath = os.environ.get('CI_PROJECT_PATH')
    nombreProducto = os.environ.get('PRODUCT_NAME')
    versionProducto = os.environ.get('PRODUCT_VERSION')
    organizacion = os.environ.get('ORGANIZACION')
    catalogo = os.environ.get('CATALOGO')
    # Split CI_PROJECT_PATH into base path and project path
    pathParts = projectPath.split('/') if projectPath else []
    ciCustomBasePath = '/'.join(pathParts[:2]) if len(pathParts) >= 2 else ''
    ciCustomProjectPath = '/'.join(pathParts[2:]) if len(pathParts) > 2 else ''
    directorio = '.'
    with open('config_files/subscription/varenvironment.yml', 'r') as varyaml:
        connvar = yaml.safe_load(varyaml)
    patron = r"/([^/]+)/([^/]+)$"
    resultado = re.search(patron, pathGit)
    
    variableMap = {
        'environment': environment,
        'organizacion': organizacion,
        'catalogo': catalogo,
        'nameProduct': nombreProducto,
        'versionProduct': versionProducto,
        #'nameProductyaml': namefile,
        'urlmanager': connvar['environment'][environment]['urlmanager'],
        'realm': connvar['environment'][environment]['realm'],
        'aws_da': connvar['environment'][environment]['aws_da'],
        'aws_dr': connvar['environment'][environment]['aws_dr'],
        'region': connvar['environment'][environment]['region'],
        #'plans': plansresult,
        'projectPath': projectPath,
        'ciCustomBasePath': ciCustomBasePath,
        'ciCustomProjectPath': ciCustomProjectPath
    }

    print(json.dumps(variableMap, indent=4))
    filevars.formater(variableMap,'detail_vars.yaml')
    
    # Create .env file
    with open('build_vars.env', 'w') as env_file:
        for key, value in variableMap.items():
            env_file.write(f"{key.upper()}={value}\n")
