from vars.Formatted import Formatfunc
from vars.Apicrest import Apicrequest
from vars.Awsrest import Awsrequest
from common.Validation import check_environment
from common.Validation import validate_required_fields
from common.Output import write_result

import os
import yaml
import json

def main():
    try:
        with open('config_files/consumer_org/varenvironment.yml', 'r') as varyaml:
            connvar = yaml.safe_load(varyaml)

        # Validaciones
        check_environment(os.environ.get('envi'))

        variableMap = {
            'environment': os.environ.get('envi'),
            'organizacion': os.environ.get('Organizacion'),
            'catalogo': os.environ.get('Catalogo'),
            'consumerOrg': os.environ.get('Nombre'),
            'urlmanager': connvar['environment'][os.environ.get('envi')]['urlmanager'],
            'realm': connvar['environment'][os.environ.get('envi')]['realm'],
            'aws_da': connvar['environment'][os.environ.get('envi')]['aws_da'],
            'aws_dr': connvar['environment'][os.environ.get('envi')]['aws_dr'],
            'region': connvar['environment'][os.environ.get('envi')]['region'],
            'secretrefix': connvar['environment'][os.environ.get('envi')]['secretrefix'],
            'policyfile': connvar['environment'][os.environ.get('envi')]['policyfile']
        }
        validate_required_fields(variableMap,["environment", "organizacion", "catalogo", "consumerOrg"])

        print("**********************************")
        print("Ejecuccion Creacion Consumer Org Apiconnect")
        print("Ambiente: " + os.environ.get('envi'))
        print("Organizacion: " + os.environ.get('Organizacion'))
        print("Catalogo: " + os.environ.get('Catalogo'))
        print("Nombre ConsumerOrg: " + os.environ.get('Nombre'))

        print("**********************************")

        secrets = Awsrequest(variableMap)
        newconsumerorgcreate = Apicrequest(variableMap)
        filevars = Formatfunc(variableMap)

        loginApi = secrets.getSecret(
            connvar['environment']['production']['aws_da'],
            connvar['environment']['production']['aws_dr']
        )
        print("Obteniendo Token")
        newconsumerorgcreate.getToken(loginApi)

        print("***************Creando Organizacion de Consumo *******************")
        userdata = newconsumerorgcreate.getUserDetail()
        print(userdata)
    
        resultcreateconsumerorg = newconsumerorgcreate.createConsumerOrg(userdata)
        print(resultcreateconsumerorg)

        if (resultcreateconsumerorg.status_code != 201):
            raise Exception("Error creacion de la consumer org")

        print("***********FIN CREACION *************")

    except ValueError as e:
        print(f"Error: {str(e)}")
        if "Ambiente no corresponde" in str(e):
            write_result(400, "Ambiente invalido")
            raise Exception("Error creacion de la consumer org")
        elif "Uno o más valores no validos" in str(e):
            write_result(400, "Uno o mas valores no validos")
            raise Exception("Error creacion de la consumer org")
        else:
            write_result(500, "Ocurrio un error")
            raise Exception("Error creacion de la consumer org")
    except Exception as e:
        print(f"Error: {str(e)}")
        write_result(500, "Ocurrio un error")
        raise Exception("Error creacion de la consumer org")

if __name__ == "__main__":
    main()