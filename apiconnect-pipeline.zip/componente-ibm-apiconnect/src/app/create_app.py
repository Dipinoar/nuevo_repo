from vars.Formatted import Formatfunc
from vars.Apicrest import Apicrequest
from vars.Awsrest import Awsrequest
from common.Validation import check_environment
from common.Validation import validate_required_fields
from common.Output import write_result

import os
import yaml
import json

def main():
    try:
        with open('config_files/app/varenvironment.yml', 'r') as varyaml:
            connvar = yaml.safe_load(varyaml)

        # Validaciones
        check_environment(os.environ.get('envi'))

        variableMap = {
            'environment': os.environ.get('envi'),
            'organizacion': os.environ.get('Organizacion'),
            'catalogo': os.environ.get('Catalogo'),
            'consumerOrg': os.environ.get('Consumer_org'),
            'nombreAPP': os.environ.get('Nombre'),
            'tituloAPP': os.environ.get('Nombre'),
            'urlmanager': connvar['environment'][os.environ.get('envi')]['urlmanager'],
            'realm': connvar['environment'][os.environ.get('envi')]['realm'],
            'aws_da': connvar['environment'][os.environ.get('envi')]['aws_da'],
            'aws_dr': connvar['environment'][os.environ.get('envi')]['aws_dr'],
            'region': connvar['environment'][os.environ.get('envi')]['region'],
            'secretrefix': connvar['environment'][os.environ.get('envi')]['secretrefix'],
            'policyfile': connvar['environment'][os.environ.get('envi')]['policyfile']
        }
        validate_required_fields(variableMap,["environment", "organizacion", "catalogo", "consumerOrg", "nombreAPP", "tituloAPP"])

        print("**********************************")
        print("Ejecuccion Creacion Aplicaciones Apiconnect")
        print("Ambiente: " + os.environ.get('envi'))
        print("Organizacion: " + os.environ.get('Organizacion'))
        print("Catalogo: " + os.environ.get('Catalogo'))
        print("Organizacion Consumo: " + os.environ.get('Consumer_org'))
        print("Nombre APP: " + os.environ.get('Nombre'))

        print("**********************************")

        secrets = Awsrequest(variableMap)
        newappcreate = Apicrequest(variableMap)
        filevars = Formatfunc(variableMap)

        loginApi = secrets.getSecret(
            connvar['environment']['production']['aws_da'],
            connvar['environment']['production']['aws_dr']
        )
        print("Obteniendo Token")
        newappcreate.getToken(loginApi)

        print("***************Organizacion de Consumo Revision*******************")
        resultxname = newappcreate.getConsumerOrgxName()
        print(resultxname)


        if not resultxname['check']:
            print("***************Creando Organizacion de Consumo *******************")
            userdata = newappcreate.getUserDetail()
            print(userdata)
        
            resultcreateconsumerorg = newappcreate.createConsumerOrg(userdata)
            print(resultcreateconsumerorg)

        else:
            print("***************Encontrado, Detalle Organizacion de Consumo *******************")
            print(json.dumps(resultxname['result'], indent=4))
        print("***************Creacion de aplicacion *******************")
        resultGetApp = newappcreate.getAppDetail()
        if not resultGetApp['check']:
            print("***************Creando nueva aplicacion *******************")
            resultcreateapp = newappcreate.createApp()
            print("***************respuesta crear app *******************")
            if (resultcreateapp.status_code != 201):
                raise Exception("Error creacion de la app")
            
            resultCreateSecret = secrets.Createsecretaws(resultcreateapp.json())
            print("***************respuesta crear secreto*******************")
            
            fileResponse = filevars.formater(variableMap,resultcreateapp.json(),resultCreateSecret, write_result)
        else:
            print("***************Encontrado, Detalle Aplicacion *******************")
            print(json.dumps(resultGetApp['result'], indent=4))
            write_result(400, "La aplicacion ya existe.")
            raise Exception("Error creacion de la app")

        print("***********FIN CREACION *************")

    except ValueError as e:
        print(f"Error: {str(e)}")
        if "Ambiente no corresponde" in str(e):
            write_result(400, "Ambiente invalido")
            raise Exception("Error creacion de la app")
        elif "Uno o más valores no validos" in str(e):
            write_result(400, "Uno o mas valores no validos")
            raise Exception("Error creacion de la app")
        else:
            write_result(500, "Ocurrio un error")
            raise Exception("Error creacion de la app")
    except Exception as e:
        print(f"Error: {str(e)}")
        write_result(500, "Ocurrio un error")
        raise Exception("Error creacion de la capp")

if __name__ == "__main__":
    main()